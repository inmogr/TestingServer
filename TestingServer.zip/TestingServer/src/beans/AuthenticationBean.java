package beans;

import javax.servlet.http.HttpServletRequest;

import classes.Users;

public class AuthenticationBean {
	
	protected HttpServletRequest request;
	protected UserBean user;
	protected boolean isAuthenticated;
	
	public String signIn(UserBean user) {
		int index = Users.isUserExists(user.getUsername(), request);
		if (index == -1) {
			return "User does not exist";
		}
		String signIn = Users.isPasswordMatches(user.getPassword(), index);
		if (signIn.equals("Successful")) {
			this.user = user.copy();
			isAuthenticated = true;
		}
		else {
			this.user = null;
			isAuthenticated = false;
		}
		return signIn;
	}
	
	public String signUp(UserBean user) {
		int index = Users.isUserExists(user.getUsername(), request);
		if (index > -1) {
			return "User exists";
		}
		Users.add(user.copy());
		Users.update(request);
		return signIn(user);
	}
	
	public void signOut() {
		user = null;
		isAuthenticated = false;
	}
	
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	
	public UserBean getUser() {
		return user.copy();
	}
	
	public boolean isAuthenticated() {
		return true && isAuthenticated;
	}

}
