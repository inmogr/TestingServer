package beans;

import java.util.ArrayList;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import classes.HttpRequest;

public class QuestionBean {
	
	public boolean isStatus() {
		JsonObject response;
		try {
			response = HttpRequest.request();
		} catch (Exception e) {
			response = new JsonObject();
		}
		if (response.has("status")) {
			status = response.get("status").getAsString();
		}
		else {
			status = "failed";
		}
		if (response.has("question")) {
			question = response.get("question").getAsString();
		}
		else {
			question = "";
		}
		if (response.has("options")) {
			options = response.get("options").getAsJsonArray();
		}
		else {
			options = new JsonArray();
		}
		return status.equals("successful");
	}
	
	public boolean hasOptions() {
		return options.size() > 0;
	}
	
	protected String status = "";
	protected String question = "";
	protected JsonArray options = new JsonArray();
	protected int index = -1;
	
	public QuestionBean() {}
	
	public QuestionBean(String status, String question, JsonArray options, int index) {
		this.status = status;
		this.question = question;
		this.options = options;
		this.index = index;
	}
	
	public String getStatus() {
		return status;
	}
	
	public String getQuestion() {
		return question;
	}
	
	public JsonArray getOptions() {
		return options;
	}
	
	public int getIndex() {
		return index;
	}
	
	public void setIndex(int index) {
		this.index = index;
	}
	
	public QuestionBean copy() {
		return new QuestionBean(status, question, options, index);
	}
	
	public ArrayList<String> getExportable() {
		ArrayList<String> details = new ArrayList<>();
		details.add(status);
		details.add(question);
		String options = "";
		if (this.options.size() > 0) {
			options += this.options.get(0).getAsString();
			for (int i = 1; i < this.options.size(); i++) {
				options += ";" + this.options.get(i).getAsString();
			}
		}
		details.add(options);
		details.add(""+index);
		return details;
	}

}
