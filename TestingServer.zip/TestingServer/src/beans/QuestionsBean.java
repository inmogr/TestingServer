package beans;

import java.util.ArrayList;

import classes.HttpRequestString;
import classes.Question;
import classes.QuestionSet;
import classes.RequestProcessor;
import classes.ResponseProcessor;

public class QuestionsBean {
	
	private String status = "";
	private int index = -1;
	private ArrayList<Question> questions = new ArrayList<>();
	
	private int preIndex = -1;
	private String answer = "";
	
	private AuthenticationBean auth;
	
	public void setIndex(int index) {
		if (index == -1) {
			questions.clear();
			status = "";
		}
		this.index = index;
	}
	
	public void setPreIndex(int preIndex) {
		this.preIndex = preIndex;
		setQuestionAnswer();
	}
	
	public void setAnswer(String answer) {
		this.answer = answer;
		setQuestionAnswer();
	}

	public boolean isIndexResult() {
		return index == questions.size() && questions.size() != 0; // the extra index used for results 
	}
	
	public boolean isIndexValid() {
		return -1 < index && index < questions.size(); 
	}
	
	public boolean isStatusSuccessful() {
		if (questions.size() == 0) {
			setQuestions();
		}
		return status.equals("successful");
	}
	
	public boolean hasOptions() {
		return index < questions.size() && 1 < questions.get(index).options.length;
	}

	private void setQuestions() {
		try {
			// MUST CHANGE IT // call for questions
			String url = "http://localhost:8080/DummyServer/data2";
			String response = HttpRequestString.request(url);
			QuestionSet set = ResponseProcessor.responseQuestions(response);
			questions.addAll(set.questions);
			status = "successful";
		} catch (Exception e) {
			status = "failed";
		}
	}
	
	private void setQuestionAnswer() {
		if (-1 < preIndex && !answer.equals("")) {
			if (-1 < preIndex && preIndex < questions.size()) {
				questions.get(preIndex).answer = answer;
				fetchMark(preIndex);
			}
			preIndex = -1;
			answer = "";
		}
	}
	
	public void setAuth(AuthenticationBean auth) {
		this.auth = auth;
	}
	
	private void fetchMark(int preIndex) {
		String request;
		if (getQuestion(preIndex).options.length == 4) {
			request = RequestProcessor.requestResult("C", preIndex, auth.getUser().getFullName(), "M", getQuestion(preIndex).answer);
		}
		else {
			request = RequestProcessor.requestResult("C", preIndex, auth.getUser().getFullName(), "L", getQuestion(preIndex).options[0], getQuestion(preIndex).answer);
		}
		// MUST CHANGE IT // call for results
		String url = "http://localhost:8080/DummyServer/data3";
		try {
			String response = HttpRequestString.post(url, request);
			getQuestion(preIndex).result = ResponseProcessor.responseResult(response).result;
		} catch (Exception e) {}
	}

	public String getStatus() {
		return status;
	}
	
	public int getIndex() {
		return index;
	}
	
	public Question getQuestion(int index) {
		return questions.get(index);
	}
	
	public Question getCurrentQuestion() {
		return questions.get(index);
	}
	
	public String getCurrentQuestionIfChecked(String optionView) {
		Question question = getCurrentQuestion();
		if (optionView.equals(question.answer)) {
			return "checked";
		}
		return "";
	}
	
	public String getCurrentQuestionValue() {
		Question question = getCurrentQuestion();
		return question.answer;
	}
	
	public String getTotalScore() {
		int total = questions.size();
		for (Question question : questions) {
			total -= question.result;
		}
		return total + "/" + questions.size();
	}
	
	public String toString() {
		String response = "Status: " + status;
		response += "\n";
		response += "Index: " + index;
		response += "\n";
		response += "Questions Size: " + questions.size();
		return response;
	}
	
}
