package beans;

import java.util.ArrayList;

public class UserBean {
	
	protected String username = "";
	protected String password = "";
	protected String fName = "";
	protected String lName = "";
	
	protected String method = "";
	
	public UserBean() {}
	
	public UserBean(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	public UserBean(String username, String password, String fName, String lName) {
		this(username, password);
		this.fName = fName;
		this.lName = lName;
	}
	
	public String getUsername() {
		return username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public String getfName() {
		return fName;
	}
	
	public String getlName() {
		return lName;
	}
	
	public String getMethod() {
		return method;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setfName(String fName) {
		this.fName = fName;
	}
	
	public void setlName(String lName) {
		this.lName = lName;
	}
	
	public void setMethod(String method) {
		this.method = method;
	}
	
	public UserBean copy() {
		return new UserBean(username, password, fName, lName);
	}
	
	public ArrayList<String> getExportable() {
		ArrayList<String> details = new ArrayList<>();
		details.add(username);
		details.add(password);
		details.add(fName);
		details.add(lName);
		return details;
	}

	public String getFullName() {
		return fName + " " + lName;
	}

}
