package classes;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class HttpRequest {

	public static JsonObject request() throws MalformedURLException, ProtocolException, IOException {
		JsonObject json = new JsonObject();
		HttpURLConnection connection = null;
		String url = "http://localhost:8080/DummyServer/data";
		try {
			URL myurl = new URL(url);
			connection = (HttpURLConnection) myurl.openConnection();
			connection.setRequestMethod("GET");
			StringBuilder content;
			try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
				String line;
				content = new StringBuilder();
				while ((line = in.readLine()) != null) {
					content.append(line);
					content.append(System.lineSeparator());
				}
			}
			JsonParser parser = new JsonParser();
			JsonElement element = parser.parse(content.toString());
			if (element != null) {
				json = element.getAsJsonObject();
				return json;
			}
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
		json.addProperty("status", "failed");
		return json;
	}

}
