package classes;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class HttpRequestString {

	public static String request(String url) throws MalformedURLException, ProtocolException, IOException {
		HttpURLConnection connection = null;
		try {
			URL myurl = new URL(url);
			connection = (HttpURLConnection) myurl.openConnection();
			connection.setRequestMethod("GET");
			StringBuilder content;
			try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
				String line;
				content = new StringBuilder();
				while ((line = in.readLine()) != null) {
					content.append(line);
					content.append(System.lineSeparator());
				}
			}
			return content.toString();
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
	}
	
	public static String post(String url, String parameters) throws MalformedURLException, ProtocolException, IOException {
		HttpURLConnection connection = null;
		try {
			URL myurl = new URL(url);
			connection = (HttpURLConnection) myurl.openConnection();
			connection.setRequestMethod("POST");
			byte[] postData = parameters.getBytes(StandardCharsets.UTF_8);
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "text/html");
			//connection.setRequestProperty("User-Agent", "Java client");
            try (DataOutputStream dataOutputStream = new DataOutputStream(connection.getOutputStream())) {
                dataOutputStream.write(postData);
            }
			StringBuilder content;
			try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
				String line;
				content = new StringBuilder();
				while ((line = in.readLine()) != null) {
					content.append(line);
					content.append(System.lineSeparator());
				}
			}
			return content.toString();
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
	}

}
