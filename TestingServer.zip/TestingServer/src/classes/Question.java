package classes;

public class Question {
	public int index;
	public String question;
	public String[] options;
	public String answer = "";
	public int result = 1;
}
