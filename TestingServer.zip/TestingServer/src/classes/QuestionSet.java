package classes;

import java.util.ArrayList;

public class QuestionSet {
	public String MSG_TYPE;
	public ArrayList<Question> questions = new ArrayList<>();
}
