package classes;

public class RequestProcessor {
	
	public static String requestQuestions(String MSG_TYPE, String numQuestions) {
		return MSG_TYPE + ";" + numQuestions;
	}
	
	public static String requestQuestions(String MSG_TYPE, int numQuestions) {
		return requestQuestions(MSG_TYPE, ""+numQuestions);
	}
	
	public static String requestResult(String MSG_TYPE, String index, String name, String type, String optionPicked) {
		return MSG_TYPE + "|" + index + ";" + addQuotes(name) + ";" + type + ";" + optionPicked;
	}
	
	public static String requestResult(String MSG_TYPE, int index, String name, String type, String optionPicked) {
		return requestResult(MSG_TYPE, ""+index, name, type, optionPicked);
	}
	
	public static String requestResult(String MSG_TYPE, String index, String name, String type, String language, String code) {
		return MSG_TYPE + "|" + index + ";" + addQuotes(name) + ";" + type + ";" + language + ";" + code;
	}
	
	public static String requestResult(String MSG_TYPE, int index, String name, String type, String language, String code) {
		return requestResult(MSG_TYPE, ""+index, name, type, language, code);
	}
	
	public static String addQuotes(String string) {
		return "\"" + string + "\"";
	}

}
