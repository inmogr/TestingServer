package classes;

public class ResponseProcessor {
	
	public static Result responseResult(String response) {
		Result result = new Result();
		int tempIndex;
		tempIndex = 1;
		result.MSG_TYPE = response.substring(0, tempIndex);
		response = response.substring(tempIndex+1);
		tempIndex = response.indexOf(";");
		result.index = Integer.parseInt(response.substring(0, tempIndex));
		response = response.substring(tempIndex+1);
		if (response.contains("0"))
			result.result = 0;
		else
			result.result = 1;
		return result;
	}
	
	public static QuestionSet responseQuestions(String response) {
		QuestionSet set = new QuestionSet();
		int tempIndex;
		tempIndex = 1;
		set.MSG_TYPE = response.substring(0, tempIndex);
		while (tempIndex > -1) {
			Question question = new Question();
			response = response.substring(tempIndex+1);
			tempIndex = response.indexOf(";");
			question.index = Integer.parseInt(response.substring(0, tempIndex));
			response = response.substring(tempIndex+1);
			tempIndex = response.indexOf(";");
			String type = response.substring(0, tempIndex);
			response = response.substring(tempIndex+1);
			tempIndex = response.indexOf(";");
			question.question = response.substring(0, tempIndex);
			response = response.substring(tempIndex+1);
			if (type.equals("M")) {
				question.options = new String[4];
				for (int i = 0; i < question.options.length - 1; i++) {
					tempIndex = response.indexOf(",");
					question.options[i] = response.substring(0, tempIndex);
					response = response.substring(tempIndex+1);
				}
				if (tempIndex > -1)
					question.options[3] = response.substring(0, tempIndex);
				else
					question.options[3] = response;
			}
			else if (type.equals("L")) {
				question.options = new String[1];
				tempIndex = response.indexOf(";");
				if (tempIndex > -1)
					question.options[0] = response.substring(0, tempIndex);
				else
					question.options[0] = response;
			}
			tempIndex = response.indexOf(";");
			set.questions.add(question);
		}
		return set;
	}

}
