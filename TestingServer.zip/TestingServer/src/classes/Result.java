package classes;

public class Result {
	public String MSG_TYPE;
	public int index;
	public int result = 1;
}
