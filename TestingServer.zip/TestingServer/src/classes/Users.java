package classes;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import beans.UserBean;
import util.CsvReader;
import util.CsvWriter;

public class Users {
	
	private static final String[] attributes = {"username", "password", "fName", "lName"};
	private static ArrayList<UserBean> users = new ArrayList<>();
	private static ArrayList<String> ids = new ArrayList<>();
	
	public static void add(String username, String password, String fName, String lName) {
		UserBean user = new UserBean(username, password, fName, lName);
		add(user);
	}
	
	public static void add(UserBean user) {
		ids.add(user.getUsername());
		users.add(user);
	}
	
	public static void clear() {
		users.clear();
		ids.clear();
	}
	
	public static int isUserExists(String username, HttpServletRequest request) {
		if (ids.size() == 0) {
			CsvReader.readUsers(request);
		}
		return ids.indexOf(username);
	}
	
	public static String isPasswordMatches(String password, int index) {
		if (index > -1 && index < ids.size()) {
			if (users.get(index).getPassword().equals(password)) {
				return "Successful";
			}
			else {
				return "Password does not match";
			}
		}
		return "Invalid request";
	}

	public static void update(HttpServletRequest request) {
		try {
			String path = request.getServletContext().getAttribute("FILES_DIR")+File.separator+"users.csv";
			FileWriter writer = new FileWriter(path);
			CsvWriter.writeLine(writer, getList(attributes));
			for (UserBean user : users) {
				CsvWriter.writeLine(writer, user.getExportable());
			}
			writer.flush();
			writer.close();
		} catch (Exception e) {}
	}

	private static List<String> getList(String[] attributes2) {
		List<String> list = new ArrayList<>();
		for (String string : attributes) {
			list.add(string);
		}
		return list;
	}

}
