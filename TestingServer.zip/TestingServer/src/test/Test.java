package test;

//import classes.QuestionSet;
//import classes.ResponseProcessor;
//import classes.Result;

public class Test {

	public Test() {
		//
	}
	
//	public static void main(String[] args) {
//		Result result = ResponseProcessor.responseResult("C|29;0");
//		System.out.println(result.MSG_TYPE);
//		System.out.println(result.index);
//		System.out.println(result.result);
//		result = ResponseProcessor.responseResult("C|16;1");
//		System.out.println(result.MSG_TYPE);
//		System.out.println(result.index);
//		System.out.println(result.result);
//		System.out.println("\n\n");
//		QuestionSet set = ResponseProcessor.responseQuestions("Q|4;M;What is an int;number,text,boolean,pointer;29;L;write a hello world program;J;4;M;What is an int;number,text,boolean,pointer;4;M;What is an int;number,text,boolean,pointer;29;L;write a hello world program;J;29;L;write a hello world program;J");
//		System.out.println(set.MSG_TYPE);
//		int index = 3;
//		if (set.questions.size() > index) {
//			System.out.println(set.questions.get(index).index);
//			System.out.println(set.questions.get(index).question);
//			if (set.questions.get(index).options.length == 1) {
//				System.out.println(set.questions.get(index).options[0]);
//			}
//			else {
//				for (String option : set.questions.get(index).options) {
//					System.out.println(option);
//				}
//			}
//		}
//		else {
//			System.out.println("out of bound");
//		}
//	}

}
